#!/bin/bash

if [ "$#" -lt 2 ]; then
	echo "Insufficient Parameters"
	exit 1
fi
Output_file="output.txt"
echo "Output Summary" > "$Output_file"
Input_file="$1"
shift
while IFS= read -r line; do
	for word in "$@"; do
		if echo "$line" | grep -wq "$word"; then
			echo "$line" >> "$Output_file"
			echo "$count"	
			break
		fi
	done
done < "$Input_file"
echo "File Processing Completed..."
